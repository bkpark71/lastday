package scoresort;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class ScoreSort {
  public static void main(String[] args) {

    ArrayList<Student> list = new ArrayList<Student>();

    list.add(new Student("홍길동",1,100,90,100));
    list.add(new Student("이순신",2,90,90,80));
    list.add(new Student("아이유",3,80,80,60));

    Collections.sort(list); // list에 저장된 요소들을 정렬한다.(compareTo()호출)
    Iterator it = list.iterator();

    while(it.hasNext())
      System.out.println(it.next());
  }
}


