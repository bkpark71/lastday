package scoresort;

public class Student implements Comparable{
  private String name;
  private int number;
  private int eng;
  private int prg;
  private int math;

  Student(){
    this("",0,0,0,0);
  }
  public Student(String name, int number, int eng, int prg, int math) {
    this.name = name;
    this.number = number;
    this.eng = eng;
    this.prg = prg;
    this.math = math;
  }

  @Override
  public int compareTo(Object o) {
    Student s1 = new Student();
    if(o instanceof Student) {
      s1 = (Student) o;
      double avg1 = getAvg();
      double avg2 = s1.getAvg();
      return avg1 > avg2 ? 1 : (avg1 < avg2 ? -1 : 0);
    }else return -1;
  }

  private int getTotal(){
    return eng + prg + math;
  }
  public float getAvg(){
    return (int)((getTotal()/ 3f)*10+0.5)/10f;
  }

  @Override
  public String toString() {
    return "학생정보 {" +
        "이름 : '" + name + '\'' +
        ", 번호 : " + number +
        ", 영어 : " + eng +
        ", 프로그램 : " + prg +
        ", 수학 : " + math +
        ", 평균 : " + this.getAvg() +
        '}';
  }
}
